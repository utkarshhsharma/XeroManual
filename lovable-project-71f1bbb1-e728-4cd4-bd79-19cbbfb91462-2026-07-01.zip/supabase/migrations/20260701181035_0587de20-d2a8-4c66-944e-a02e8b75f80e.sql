
CREATE POLICY "public read media objects" ON storage.objects FOR SELECT USING (bucket_id = 'media');
CREATE POLICY "admin upload media objects" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'media' AND public.is_admin());
CREATE POLICY "admin update media objects" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'media' AND public.is_admin());
CREATE POLICY "admin delete media objects" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'media' AND public.is_admin());
