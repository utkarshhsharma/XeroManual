import { createFileRoute } from "@tanstack/react-router";
import { Check, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { useServices, useSiteSettings } from "@/lib/site-data";
import { getIcon } from "@/lib/icons";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — XeroManual AI Automation" },
      { name: "description", content: "Explore XeroManual's AI automation services: receptionists, booking agents, WhatsApp bots, CRM integrations, and custom AI employees." },
      { property: "og:title", content: "Services — XeroManual" },
      { property: "og:description", content: "AI automations tailored to your business." },
    ],
  }),
  component: Services,
});

function Services() {
  const { data: services } = useServices();
  const { data: settings } = useSiteSettings();

  return (
    <SiteLayout>
      <section className="pt-20 pb-10">
        <div className="container-app text-center">
          <p className="text-sm font-semibold text-primary-glow mb-3">Our Services</p>
          <h1 className="text-4xl md:text-6xl font-bold text-gradient max-w-3xl mx-auto">
            Automations that quietly run your business
          </h1>
          <p className="mt-5 max-w-2xl mx-auto text-muted-foreground">
            Every service is custom-built for your workflow, your tools, and your customers. No cookie-cutter templates.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="container-app space-y-16">
          {(services ?? []).map((s, idx) => {
            const Icon = getIcon(s.icon);
            const reverse = idx % 2 === 1;
            return (
              <div key={s.id} id={s.slug} className={`grid lg:grid-cols-5 gap-10 items-start ${reverse ? "" : ""}`}>
                <div className={`lg:col-span-2 ${reverse ? "lg:order-2" : ""}`}>
                  <div className="glow-card p-8">
                    <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-brand-gradient shadow-glow mb-6">
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <h2 className="text-2xl md:text-3xl font-bold mb-3">{s.name}</h2>
                    <p className="text-muted-foreground leading-relaxed mb-6">{s.long_description || s.short_description}</p>
                    <a
                      href={settings?.meeting_link ?? "#"}
                      target="_blank" rel="noopener noreferrer"
                      className="btn-primary text-sm"
                    >
                      Get a Custom Quote <ArrowRight className="h-4 w-4" />
                    </a>
                  </div>
                </div>
                <div className={`lg:col-span-3 grid sm:grid-cols-2 gap-6 ${reverse ? "lg:order-1" : ""}`}>
                  <div className="glow-card p-6">
                    <h3 className="text-sm font-semibold text-primary-glow uppercase tracking-wider mb-4">Features</h3>
                    <ul className="space-y-3">
                      {s.features.map((f, i) => (
                        <li key={i} className="flex gap-2 text-sm">
                          <Check className="h-4 w-4 mt-0.5 text-primary-glow flex-shrink-0" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="glow-card p-6">
                    <h3 className="text-sm font-semibold text-primary-glow uppercase tracking-wider mb-4">Use Cases</h3>
                    <ul className="space-y-3">
                      {s.use_cases.map((u, i) => (
                        <li key={i} className="flex gap-2 text-sm">
                          <span className="h-1.5 w-1.5 mt-2 rounded-full bg-primary-glow flex-shrink-0" />
                          <span>{u}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </SiteLayout>
  );
}
