import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Sparkles, Star } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { useHomepageContent, useServices, useSiteSettings } from "@/lib/site-data";
import { getIcon } from "@/lib/icons";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const { data: hp } = useHomepageContent();
  const { data: services } = useServices();
  const { data: settings } = useSiteSettings();

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10" style={{ background: "var(--gradient-hero)" }} />
        <div className="container-app pt-24 pb-20 md:pt-32 md:pb-28 text-center">
          <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-muted-foreground mb-8">
            <Sparkles className="h-3 w-3 text-primary-glow" />
            {hp?.hero_eyebrow ?? "AI Automation Agency"}
          </div>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
            <span className="text-gradient">{hp?.hero_headline ?? "AI Automation That Runs Your Business On Autopilot"}</span>
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-base md:text-lg text-muted-foreground leading-relaxed">
            {hp?.hero_subheadline}
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary">
              Book a Free Demo <ArrowRight className="h-4 w-4" />
            </a>
            <Link to="/packages" className="btn-ghost">View Packages</Link>
          </div>
          <div className="mt-16 flex flex-wrap justify-center gap-6 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-primary-glow" /> Live in under 14 days</span>
            <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-primary-glow" /> Custom, not templated</span>
            <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-primary-glow" /> Ongoing support included</span>
          </div>
        </div>
      </section>

      {/* WHAT WE AUTOMATE */}
      <section className="section">
        <div className="container-app">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-sm font-semibold text-primary-glow mb-2">What We Automate</p>
            <h2 className="text-3xl md:text-5xl font-bold text-gradient">Six ways to put your business on autopilot</h2>
            <p className="mt-4 text-muted-foreground">Pick one, stack a few, or hand us your whole ops backbone.</p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(services ?? []).map((s) => {
              const Icon = getIcon(s.icon);
              return (
                <div key={s.id} className="glow-card p-7 flex flex-col">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-gradient shadow-soft mb-5">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{s.name}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-6 flex-1">{s.short_description}</p>
                  <Link to="/services" hash={s.slug} className="inline-flex items-center gap-1 text-sm font-semibold text-primary-glow hover:gap-2 transition-all">
                    Learn more <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section">
        <div className="container-app">
          <div className="grid lg:grid-cols-2 gap-14 items-start">
            <div>
              <p className="text-sm font-semibold text-primary-glow mb-2">Why XeroManual</p>
              <h2 className="text-3xl md:text-5xl font-bold text-gradient">Built for operators who value speed and craft</h2>
            </div>
            <div className="space-y-6">
              {(hp?.why_choose_us ?? []).map((w, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex-shrink-0 flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient shadow-soft">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">{w.title}</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">{w.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section">
        <div className="container-app">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-sm font-semibold text-primary-glow mb-2">Loved by Operators</p>
            <h2 className="text-3xl md:text-5xl font-bold text-gradient">What our clients say</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {(hp?.testimonials ?? []).map((t, i) => (
              <div key={i} className="glow-card p-7">
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-primary-glow text-primary-glow" />
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-6">"{t.quote}"</p>
                <div>
                  <p className="text-sm font-semibold">{t.author}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section">
        <div className="container-app">
          <div className="glow-card p-10 md:p-16 text-center">
            <h2 className="text-3xl md:text-5xl font-bold text-gradient max-w-2xl mx-auto">
              Ready to give your business an AI backbone?
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Book a free 30-minute strategy call. We'll map out exactly what to automate first.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary">
                Book a Free Demo <ArrowRight className="h-4 w-4" />
              </a>
              <Link to="/packages" className="btn-ghost">See Pricing</Link>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
