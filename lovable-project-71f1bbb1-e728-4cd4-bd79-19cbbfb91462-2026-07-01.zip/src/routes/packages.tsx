import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Check, Sparkles, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { usePackages, useSiteSettings } from "@/lib/site-data";
import { CURRENCIES, detectCurrency, formatPrice } from "@/lib/currency";

export const Route = createFileRoute("/packages")({
  head: () => ({
    meta: [
      { title: "Packages — XeroManual Pricing" },
      { name: "description", content: "Transparent pricing for AI automation packages. Starter, Growth, and Enterprise plans available." },
      { property: "og:title", content: "Packages — XeroManual" },
      { property: "og:description", content: "AI automation pricing starting from ₹3,499." },
    ],
  }),
  component: Packages,
});

function Packages() {
  const { data: packages } = usePackages();
  const { data: settings } = useSiteSettings();
  const [currencyCode, setCurrencyCode] = useState<string>("INR");

  useEffect(() => {
    detectCurrency().then((code) => setCurrencyCode(code));
  }, []);

  useEffect(() => {
    if (currencyCode) localStorage.setItem("xm_currency", currencyCode);
  }, [currencyCode]);

  const currency = CURRENCIES[currencyCode] ?? CURRENCIES.INR;

  return (
    <SiteLayout>
      <section className="pt-20 pb-12">
        <div className="container-app text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand-gradient px-4 py-1.5 text-xs font-semibold text-white shadow-glow mb-6">
            <Sparkles className="h-3 w-3" />
            Starting from {formatPrice(settings?.starting_price_inr ?? 3499, currency)} {currency.code}
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gradient max-w-3xl mx-auto">
            Pricing built for real businesses
          </h1>
          <p className="mt-5 max-w-2xl mx-auto text-muted-foreground">
            One-time build fees. No long contracts. Prices auto-convert to your local currency.
          </p>

          <div className="mt-6 inline-flex items-center gap-2 text-xs">
            <label className="text-muted-foreground">Currency:</label>
            <select
              value={currencyCode}
              onChange={(e) => setCurrencyCode(e.target.value)}
              className="rounded-full bg-white/5 border border-white/10 px-3 py-1.5 text-xs focus:outline-none focus:border-primary"
            >
              {Object.values(CURRENCIES).map((c) => (
                <option key={c.code} value={c.code} className="bg-background">{c.code}</option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="container-app">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {(packages ?? []).map((p) => (
              <div key={p.id} className={`glow-card p-8 flex flex-col relative ${p.featured ? "ring-1 ring-primary shadow-glow" : ""}`}>
                {p.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-gradient px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white shadow-glow">
                    Most Popular
                  </div>
                )}
                <div className="flex items-center gap-2 mb-3">
                  {p.badge && (
                    <span className="rounded-full glass px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider">
                      {p.badge}
                    </span>
                  )}
                  {p.short_code && (
                    <span className="rounded-md bg-white/5 border border-white/10 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                      {p.short_code}
                    </span>
                  )}
                </div>
                <h3 className="text-2xl font-bold">{p.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground min-h-[3rem]">{p.description}</p>
                <div className="my-6">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-4xl font-bold text-gradient">{formatPrice(p.price_inr, currency)}</span>
                    <span className="text-xs text-muted-foreground">{currency.code}</span>
                  </div>
                  {currency.code !== "INR" && (
                    <p className="mt-1 text-[11px] text-muted-foreground">≈ ₹{p.price_inr.toLocaleString("en-IN")} INR</p>
                  )}
                </div>
                <ul className="space-y-2.5 mb-8 flex-1">
                  {p.features.map((f, i) => (
                    <li key={i} className="flex gap-2 text-sm">
                      <Check className="h-4 w-4 mt-0.5 text-primary-glow flex-shrink-0" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex flex-col gap-2">
                  <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary text-sm w-full">
                    Buy Now <ArrowRight className="h-4 w-4" />
                  </a>
                  <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-ghost text-sm w-full">
                    Book Demo
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
