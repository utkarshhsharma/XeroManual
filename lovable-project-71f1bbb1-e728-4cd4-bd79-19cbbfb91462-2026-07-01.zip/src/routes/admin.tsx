import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import {
  LogOut, Sparkles, Settings, Package as PkgIcon, Layers, Inbox, Image as ImageIcon,
  Home as HomeIcon, Plus, Trash2, Save, Upload, X, Loader2, Mail, ExternalLink,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { iconNames } from "@/lib/icons";
import type { Service, Package, SiteSettings, HomepageContent, Lead } from "@/lib/site-data";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — XeroManual" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

type Tab = "dashboard" | "services" | "packages" | "leads" | "homepage" | "settings" | "media";

function Admin() {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("dashboard");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!user) return null;
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="glow-card p-8 max-w-md text-center">
          <h1 className="text-xl font-bold mb-2">Not authorized</h1>
          <p className="text-sm text-muted-foreground mb-6">This account isn't the site admin. Contact the site owner.</p>
          <button onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/auth" }); }} className="btn-ghost">Sign out</button>
        </div>
      </div>
    );
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "dashboard", label: "Dashboard", icon: <HomeIcon className="h-4 w-4" /> },
    { id: "services", label: "Services", icon: <Layers className="h-4 w-4" /> },
    { id: "packages", label: "Packages", icon: <PkgIcon className="h-4 w-4" /> },
    { id: "leads", label: "Leads", icon: <Inbox className="h-4 w-4" /> },
    { id: "homepage", label: "Homepage", icon: <Sparkles className="h-4 w-4" /> },
    { id: "media", label: "Media", icon: <ImageIcon className="h-4 w-4" /> },
    { id: "settings", label: "Settings", icon: <Settings className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <aside className="md:w-64 border-b md:border-b-0 md:border-r border-white/5 glass md:min-h-screen p-4 flex md:flex-col gap-1 overflow-x-auto">
        <Link to="/" className="hidden md:flex items-center gap-2 mb-6 px-2 pt-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-gradient shadow-glow">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <span className="font-display font-bold">XeroManual</span>
        </Link>
        <nav className="flex md:flex-col gap-1 flex-1">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${tab === t.id ? "bg-brand-gradient text-white shadow-soft" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}>
              {t.icon}<span>{t.label}</span>
            </button>
          ))}
        </nav>
        <button onClick={signOut} className="md:mt-auto flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:bg-white/5">
          <LogOut className="h-4 w-4" /><span>Sign out</span>
        </button>
      </aside>

      <main className="flex-1 p-6 md:p-10">
        {tab === "dashboard" && <Dashboard onNav={setTab} email={user.email ?? ""} />}
        {tab === "services" && <ServicesAdmin />}
        {tab === "packages" && <PackagesAdmin />}
        {tab === "leads" && <LeadsAdmin adminEmail={user.email ?? ""} />}
        {tab === "homepage" && <HomepageAdmin />}
        {tab === "media" && <MediaAdmin />}
        {tab === "settings" && <SettingsAdmin />}
      </main>
    </div>
  );
}

/* ---------------- Dashboard ---------------- */
function Dashboard({ onNav, email }: { onNav: (t: Tab) => void; email: string }) {
  const { data: newLeads } = useQuery({
    queryKey: ["admin_new_leads"],
    queryFn: async () => {
      const { count } = await supabase.from("leads").select("*", { count: "exact", head: true }).eq("status", "new");
      return count ?? 0;
    },
  });
  const { data: pkgCount } = useQuery({
    queryKey: ["admin_pkg_count"],
    queryFn: async () => (await supabase.from("packages").select("*", { count: "exact", head: true })).count ?? 0,
  });
  const { data: svcCount } = useQuery({
    queryKey: ["admin_svc_count"],
    queryFn: async () => (await supabase.from("services").select("*", { count: "exact", head: true })).count ?? 0,
  });

  return (
    <div className="max-w-5xl">
      <h1 className="text-3xl font-bold text-gradient">Welcome back</h1>
      <p className="mt-1 text-sm text-muted-foreground">{email}</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <StatCard label="New Leads" value={newLeads ?? 0} onClick={() => onNav("leads")} />
        <StatCard label="Services" value={svcCount ?? 0} onClick={() => onNav("services")} />
        <StatCard label="Packages" value={pkgCount ?? 0} onClick={() => onNav("packages")} />
      </div>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <QuickAction title="Edit Homepage Content" desc="Update hero, testimonials, and about text" onClick={() => onNav("homepage")} />
        <QuickAction title="Site Settings" desc="Phone, email, meeting link, and brand" onClick={() => onNav("settings")} />
      </div>
    </div>
  );
}

function StatCard({ label, value, onClick }: { label: string; value: number; onClick: () => void }) {
  return (
    <button onClick={onClick} className="glow-card p-6 text-left">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-2 text-4xl font-bold text-gradient">{value}</p>
    </button>
  );
}
function QuickAction({ title, desc, onClick }: { title: string; desc: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="glow-card p-6 text-left">
      <p className="font-semibold mb-1">{title}</p>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </button>
  );
}

/* ---------------- Services ---------------- */
function ServicesAdmin() {
  const qc = useQueryClient();
  const { data: services, isLoading } = useQuery({
    queryKey: ["admin_services"],
    queryFn: async () => (await supabase.from("services").select("*").order("sort_order")).data ?? [],
  });
  const [editing, setEditing] = useState<Partial<Service> | null>(null);

  async function save(s: Partial<Service>) {
    const payload = {
      name: s.name, slug: s.slug, short_description: s.short_description, long_description: s.long_description ?? "",
      features: s.features ?? [], use_cases: s.use_cases ?? [], icon: s.icon ?? "Sparkles",
      image_url: s.image_url ?? null, sort_order: s.sort_order ?? 0, visible: s.visible ?? true,
    };
    const res = s.id
      ? await supabase.from("services").update(payload as any).eq("id", s.id)
      : await supabase.from("services").insert(payload as any);
    if (res.error) return toast.error(res.error.message);
    toast.success("Saved");
    setEditing(null);
    qc.invalidateQueries({ queryKey: ["admin_services"] });
    qc.invalidateQueries({ queryKey: ["services"] });
  }

  async function remove(id: string) {
    if (!confirm("Delete this service?")) return;
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["admin_services"] });
    qc.invalidateQueries({ queryKey: ["services"] });
  }

  return (
    <div className="max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gradient">Services</h1>
        <button onClick={() => setEditing({ features: [], use_cases: [], icon: "Sparkles", visible: true, sort_order: (services?.length ?? 0) + 1 })} className="btn-primary text-sm">
          <Plus className="h-4 w-4" /> Add Service
        </button>
      </div>

      {isLoading ? <Loader2 className="animate-spin" /> : (
        <div className="space-y-3">
          {(services ?? []).map((s: any) => (
            <div key={s.id} className="glow-card p-5 flex items-center gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold">{s.name}</p>
                  {!s.visible && <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/5 text-muted-foreground">Hidden</span>}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">/{s.slug} · {s.icon}</p>
              </div>
              <button onClick={() => setEditing(s)} className="btn-ghost text-xs py-2 px-3">Edit</button>
              <button onClick={() => remove(s.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
      )}

      {editing && <ServiceEditor initial={editing} onClose={() => setEditing(null)} onSave={save} />}
    </div>
  );
}

function ServiceEditor({ initial, onClose, onSave }: { initial: Partial<Service>; onClose: () => void; onSave: (s: Partial<Service>) => void }) {
  const [s, setS] = useState<Partial<Service>>(initial);
  const setList = (key: "features" | "use_cases", text: string) =>
    setS({ ...s, [key]: text.split("\n").map((l) => l.trim()).filter(Boolean) });

  return (
    <Modal onClose={onClose} title={s.id ? "Edit Service" : "Add Service"}>
      <div className="space-y-4">
        <Row><FormField label="Name"><Input value={s.name ?? ""} onChange={(v) => setS({ ...s, name: v })} /></FormField>
             <FormField label="Slug"><Input value={s.slug ?? ""} onChange={(v) => setS({ ...s, slug: v })} placeholder="ai-receptionist" /></FormField></Row>
        <FormField label="Short Description"><Input value={s.short_description ?? ""} onChange={(v) => setS({ ...s, short_description: v })} /></FormField>
        <FormField label="Long Description"><Textarea rows={4} value={s.long_description ?? ""} onChange={(v) => setS({ ...s, long_description: v })} /></FormField>
        <Row><FormField label="Icon"><Select value={s.icon ?? "Sparkles"} onChange={(v) => setS({ ...s, icon: v })} options={iconNames} /></FormField>
             <FormField label="Sort Order"><Input type="number" value={String(s.sort_order ?? 0)} onChange={(v) => setS({ ...s, sort_order: parseInt(v) || 0 })} /></FormField></Row>
        <FormField label="Features (one per line)">
          <Textarea rows={5} value={(s.features ?? []).join("\n")} onChange={(v) => setList("features", v)} />
        </FormField>
        <FormField label="Use Cases (one per line)">
          <Textarea rows={4} value={(s.use_cases ?? []).join("\n")} onChange={(v) => setList("use_cases", v)} />
        </FormField>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={s.visible ?? true} onChange={(e) => setS({ ...s, visible: e.target.checked })} className="accent-primary" />
          Visible on public site
        </label>
        <div className="flex justify-end gap-2 pt-4">
          <button onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button onClick={() => onSave(s)} className="btn-primary text-sm"><Save className="h-4 w-4" /> Save</button>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- Packages ---------------- */
function PackagesAdmin() {
  const qc = useQueryClient();
  const { data: packages } = useQuery({
    queryKey: ["admin_packages"],
    queryFn: async () => (await supabase.from("packages").select("*").order("sort_order")).data ?? [],
  });
  const [editing, setEditing] = useState<Partial<Package> | null>(null);

  async function save(p: Partial<Package>) {
    const payload = {
      name: p.name, description: p.description ?? "", badge: p.badge ?? null, short_code: p.short_code ?? null,
      features: p.features ?? [], price_inr: p.price_inr ?? 5999, featured: p.featured ?? false,
      visible: p.visible ?? true, sort_order: p.sort_order ?? 0,
    };
    const res = p.id ? await supabase.from("packages").update(payload as any).eq("id", p.id) : await supabase.from("packages").insert(payload as any);
    if (res.error) return toast.error(res.error.message);
    toast.success("Saved");
    setEditing(null);
    qc.invalidateQueries({ queryKey: ["admin_packages"] });
    qc.invalidateQueries({ queryKey: ["packages"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this package?")) return;
    const { error } = await supabase.from("packages").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin_packages"] });
    qc.invalidateQueries({ queryKey: ["packages"] });
  }

  return (
    <div className="max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gradient">Packages</h1>
        <button onClick={() => setEditing({ features: [], price_inr: 5999, visible: true, sort_order: (packages?.length ?? 0) + 1 })} className="btn-primary text-sm">
          <Plus className="h-4 w-4" /> Add Package
        </button>
      </div>
      <div className="space-y-3">
        {(packages ?? []).map((p: any) => (
          <div key={p.id} className="glow-card p-5 flex items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-semibold">{p.name}</p>
                {p.featured && <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-brand-gradient text-white">Featured</span>}
                {p.badge && <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full glass">{p.badge}</span>}
                {!p.visible && <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/5 text-muted-foreground">Hidden</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">₹{p.price_inr.toLocaleString("en-IN")} INR</p>
            </div>
            <button onClick={() => setEditing(p)} className="btn-ghost text-xs py-2 px-3">Edit</button>
            <button onClick={() => remove(p.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="h-4 w-4" /></button>
          </div>
        ))}
      </div>
      {editing && <PackageEditor initial={editing} onClose={() => setEditing(null)} onSave={save} />}
    </div>
  );
}

function PackageEditor({ initial, onClose, onSave }: { initial: Partial<Package>; onClose: () => void; onSave: (p: Partial<Package>) => void }) {
  const [p, setP] = useState<Partial<Package>>(initial);
  return (
    <Modal onClose={onClose} title={p.id ? "Edit Package" : "Add Package"}>
      <div className="space-y-4">
        <Row><FormField label="Name"><Input value={p.name ?? ""} onChange={(v) => setP({ ...p, name: v })} /></FormField>
             <FormField label="Price (INR)"><Input type="number" value={String(p.price_inr ?? 5999)} onChange={(v) => setP({ ...p, price_inr: parseInt(v) || 0 })} /></FormField></Row>
        <FormField label="Description"><Textarea rows={3} value={p.description ?? ""} onChange={(v) => setP({ ...p, description: v })} /></FormField>
        <Row><FormField label="Badge"><Input value={p.badge ?? ""} onChange={(v) => setP({ ...p, badge: v })} placeholder="Pre-Built / Custom" /></FormField>
             <FormField label="Short Code"><Input value={p.short_code ?? ""} onChange={(v) => setP({ ...p, short_code: v })} placeholder="SA" /></FormField></Row>
        <FormField label="Features (one per line)">
          <Textarea rows={6} value={(p.features ?? []).join("\n")} onChange={(v) => setP({ ...p, features: v.split("\n").map((l) => l.trim()).filter(Boolean) })} />
        </FormField>
        <FormField label="Sort Order"><Input type="number" value={String(p.sort_order ?? 0)} onChange={(v) => setP({ ...p, sort_order: parseInt(v) || 0 })} /></FormField>
        <div className="flex gap-4">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={p.featured ?? false} onChange={(e) => setP({ ...p, featured: e.target.checked })} className="accent-primary" /> Featured
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={p.visible ?? true} onChange={(e) => setP({ ...p, visible: e.target.checked })} className="accent-primary" /> Visible
          </label>
        </div>
        <div className="flex justify-end gap-2 pt-4">
          <button onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button onClick={() => onSave(p)} className="btn-primary text-sm"><Save className="h-4 w-4" /> Save</button>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- Leads ---------------- */
function LeadsAdmin({ adminEmail }: { adminEmail: string }) {
  const qc = useQueryClient();
  const { data: leads } = useQuery({
    queryKey: ["admin_leads"],
    queryFn: async () => (await supabase.from("leads").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("leads").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin_leads"] });
    qc.invalidateQueries({ queryKey: ["admin_new_leads"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this lead?")) return;
    const { error } = await supabase.from("leads").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin_leads"] });
  }

  return (
    <div className="max-w-5xl">
      <h1 className="text-3xl font-bold text-gradient mb-6">Query Inbox</h1>
      <div className="space-y-3">
        {(leads ?? []).length === 0 && <p className="text-sm text-muted-foreground">No leads yet.</p>}
        {(leads as Lead[] ?? []).map((l) => (
          <div key={l.id} className="glow-card p-5">
            <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold">{l.name}</p>
                  <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${l.status === "new" ? "bg-brand-gradient text-white" : "bg-white/5 text-muted-foreground"}`}>{l.status}</span>
                  {l.query_type && <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full glass">{l.query_type}</span>}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  <a href={`mailto:${l.email}`} className="hover:text-primary-glow">{l.email}</a>
                  {l.phone && <> · <a href={`tel:${l.phone}`} className="hover:text-primary-glow">{l.phone}</a></>}
                  <> · {new Date(l.created_at).toLocaleString()}</>
                </p>
              </div>
              <div className="flex gap-2">
                <a
                  href={`mailto:${l.email}?subject=Re: Your inquiry to XeroManual&body=Hi ${encodeURIComponent(l.name)},%0D%0A%0D%0AThanks for reaching out to XeroManual.%0D%0A%0D%0A---%0D%0AOriginal message:%0D%0A${encodeURIComponent(l.message)}`}
                  className="btn-primary text-xs py-2 px-3"
                  onClick={() => setStatus(l.id, "responded")}
                >
                  <Mail className="h-3.5 w-3.5" /> Reply via Email
                </a>
                {l.status === "new" ? (
                  <button onClick={() => setStatus(l.id, "responded")} className="btn-ghost text-xs py-2 px-3">Mark responded</button>
                ) : (
                  <button onClick={() => setStatus(l.id, "new")} className="btn-ghost text-xs py-2 px-3">Reopen</button>
                )}
                <button onClick={() => remove(l.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
            <p className="text-sm text-muted-foreground whitespace-pre-line">{l.message}</p>
          </div>
        ))}
      </div>
      <p className="mt-6 text-xs text-muted-foreground">Replies go from your default mail client. Configure Outlook as your default handler to reply from {adminEmail}.</p>
    </div>
  );
}

/* ---------------- Homepage ---------------- */
function HomepageAdmin() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin_hp"],
    queryFn: async () => (await supabase.from("homepage_content").select("*").eq("id", 1).single()).data as unknown as HomepageContent,
  });
  const [f, setF] = useState<Partial<HomepageContent>>({});

  useEffect(() => { if (data) setF(data); }, [data]);

  async function save() {
    const { error } = await supabase.from("homepage_content").update({
      hero_headline: f.hero_headline, hero_subheadline: f.hero_subheadline, hero_eyebrow: f.hero_eyebrow,
      why_choose_us: f.why_choose_us ?? [], testimonials: f.testimonials ?? [],
      about_text: f.about_text, about_mission: f.about_mission,
    }).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Homepage updated");
    qc.invalidateQueries({ queryKey: ["homepage_content"] });
    qc.invalidateQueries({ queryKey: ["admin_hp"] });
  }

  return (
    <div className="max-w-4xl space-y-6">
      <h1 className="text-3xl font-bold text-gradient">Homepage Content</h1>
      <div className="glow-card p-6 space-y-4">
        <h2 className="font-semibold">Hero</h2>
        <FormField label="Eyebrow"><Input value={f.hero_eyebrow ?? ""} onChange={(v) => setF({ ...f, hero_eyebrow: v })} /></FormField>
        <FormField label="Headline"><Textarea rows={2} value={f.hero_headline ?? ""} onChange={(v) => setF({ ...f, hero_headline: v })} /></FormField>
        <FormField label="Subheadline"><Textarea rows={3} value={f.hero_subheadline ?? ""} onChange={(v) => setF({ ...f, hero_subheadline: v })} /></FormField>
      </div>
      <div className="glow-card p-6 space-y-4">
        <h2 className="font-semibold">About</h2>
        <FormField label="About Text"><Textarea rows={5} value={f.about_text ?? ""} onChange={(v) => setF({ ...f, about_text: v })} /></FormField>
        <FormField label="Mission Statement"><Textarea rows={3} value={f.about_mission ?? ""} onChange={(v) => setF({ ...f, about_mission: v })} /></FormField>
      </div>
      <JsonListEditor
        title="Why Choose Us"
        items={f.why_choose_us ?? []}
        fields={[{ key: "title", label: "Title" }, { key: "desc", label: "Description", multiline: true }]}
        onChange={(items) => setF({ ...f, why_choose_us: items as any })}
      />
      <JsonListEditor
        title="Testimonials"
        items={f.testimonials ?? []}
        fields={[{ key: "quote", label: "Quote", multiline: true }, { key: "author", label: "Author" }, { key: "role", label: "Role" }]}
        onChange={(items) => setF({ ...f, testimonials: items as any })}
      />
      <button onClick={save} className="btn-primary"><Save className="h-4 w-4" /> Save Changes</button>
    </div>
  );
}

function JsonListEditor({ title, items, fields, onChange }: {
  title: string; items: Record<string, string>[]; fields: { key: string; label: string; multiline?: boolean }[]; onChange: (items: Record<string, string>[]) => void;
}) {
  return (
    <div className="glow-card p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold">{title}</h2>
        <button onClick={() => onChange([...items, Object.fromEntries(fields.map((f) => [f.key, ""]))])} className="btn-ghost text-xs py-2 px-3">
          <Plus className="h-3.5 w-3.5" /> Add
        </button>
      </div>
      <div className="space-y-3">
        {items.map((it, i) => (
          <div key={i} className="border border-white/10 rounded-xl p-4 space-y-2 relative">
            <button onClick={() => onChange(items.filter((_, j) => j !== i))} className="absolute top-2 right-2 p-1 rounded hover:bg-destructive/20 text-destructive">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
            {fields.map((f) => (
              <FormField key={f.key} label={f.label}>
                {f.multiline
                  ? <Textarea rows={2} value={it[f.key] ?? ""} onChange={(v) => onChange(items.map((x, j) => j === i ? { ...x, [f.key]: v } : x))} />
                  : <Input value={it[f.key] ?? ""} onChange={(v) => onChange(items.map((x, j) => j === i ? { ...x, [f.key]: v } : x))} />}
              </FormField>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Settings ---------------- */
function SettingsAdmin() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin_settings"],
    queryFn: async () => (await supabase.from("site_settings").select("*").eq("id", 1).single()).data as SiteSettings,
  });
  const [f, setF] = useState<Partial<SiteSettings>>({});
  useEffect(() => { if (data) setF(data); }, [data]);

  async function save() {
    const { error } = await supabase.from("site_settings").update({
      brand_name: f.brand_name, logo_url: f.logo_url || null, phone: f.phone, email: f.email,
      meeting_link: f.meeting_link, starting_price_inr: f.starting_price_inr ?? 3499,
    }).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Settings saved");
    qc.invalidateQueries({ queryKey: ["site_settings"] });
    qc.invalidateQueries({ queryKey: ["admin_settings"] });
  }

  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="text-3xl font-bold text-gradient">Site Settings</h1>
      <div className="glow-card p-6 space-y-4">
        <FormField label="Brand Name"><Input value={f.brand_name ?? ""} onChange={(v) => setF({ ...f, brand_name: v })} /></FormField>
        <FormField label="Logo URL (pick from Media library or paste URL)">
          <div className="flex gap-2">
            <Input value={f.logo_url ?? ""} onChange={(v) => setF({ ...f, logo_url: v })} placeholder="https://..." />
            <MediaPickerButton onPick={(url) => setF({ ...f, logo_url: url })} />
          </div>
          {f.logo_url && <img src={f.logo_url} alt="logo" className="mt-2 h-10" />}
        </FormField>
        <Row><FormField label="Phone"><Input value={f.phone ?? ""} onChange={(v) => setF({ ...f, phone: v })} /></FormField>
             <FormField label="Email"><Input value={f.email ?? ""} onChange={(v) => setF({ ...f, email: v })} /></FormField></Row>
        <FormField label="Meeting Booking Link"><Input value={f.meeting_link ?? ""} onChange={(v) => setF({ ...f, meeting_link: v })} /></FormField>
        <FormField label="Starting Price (INR) — shown on Packages page">
          <Input type="number" value={String(f.starting_price_inr ?? 3499)} onChange={(v) => setF({ ...f, starting_price_inr: parseInt(v) || 0 })} />
        </FormField>
      </div>
      <button onClick={save} className="btn-primary"><Save className="h-4 w-4" /> Save Settings</button>
    </div>
  );
}

/* ---------------- Media ---------------- */
function MediaAdmin() {
  const qc = useQueryClient();
  const { data: media } = useQuery({
    queryKey: ["admin_media"],
    queryFn: async () => (await supabase.from("media").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  const [uploading, setUploading] = useState(false);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const path = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const { error } = await supabase.storage.from("media").upload(path, file, { upsert: false });
    if (error) { setUploading(false); return toast.error(error.message); }
    const { data: signed } = await supabase.storage.from("media").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
    const publicUrl = signed?.signedUrl ?? "";
    const { error: insErr } = await supabase.from("media").insert({
      file_name: file.name, storage_path: path, public_url: publicUrl, mime_type: file.type, size_bytes: file.size,
    });
    setUploading(false);
    if (insErr) return toast.error(insErr.message);
    toast.success("Uploaded");
    qc.invalidateQueries({ queryKey: ["admin_media"] });
    e.target.value = "";
  }

  async function remove(id: string, path: string) {
    if (!confirm("Delete this file?")) return;
    await supabase.storage.from("media").remove([path]);
    await supabase.from("media").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["admin_media"] });
  }

  return (
    <div className="max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gradient">Media Library</h1>
        <label className="btn-primary text-sm cursor-pointer">
          {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          Upload File
          <input type="file" accept="image/*" onChange={handleUpload} className="hidden" disabled={uploading} />
        </label>
      </div>
      <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {(media ?? []).map((m: any) => (
          <div key={m.id} className="glow-card p-3 group relative">
            <div className="aspect-square bg-white/5 rounded-lg overflow-hidden flex items-center justify-center">
              {m.mime_type?.startsWith("image/") ? (
                <img src={m.public_url} alt={m.file_name} className="w-full h-full object-cover" loading="lazy" />
              ) : <ImageIcon className="h-8 w-8 text-muted-foreground" />}
            </div>
            <p className="text-xs mt-2 truncate">{m.file_name}</p>
            <div className="flex justify-between items-center mt-2">
              <button onClick={() => { navigator.clipboard.writeText(m.public_url); toast.success("URL copied"); }}
                className="text-[11px] text-primary-glow hover:underline flex items-center gap-1">
                <ExternalLink className="h-3 w-3" /> Copy URL
              </button>
              <button onClick={() => remove(m.id, m.storage_path)} className="p-1 rounded hover:bg-destructive/20 text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MediaPickerButton({ onPick }: { onPick: (url: string) => void }) {
  const [open, setOpen] = useState(false);
  const { data: media } = useQuery({
    queryKey: ["admin_media"],
    queryFn: async () => (await supabase.from("media").select("*").order("created_at", { ascending: false })).data ?? [],
    enabled: open,
  });
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="btn-ghost text-sm py-2 px-3 whitespace-nowrap"><ImageIcon className="h-4 w-4" /> Pick</button>
      {open && (
        <Modal onClose={() => setOpen(false)} title="Pick from Media">
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4 max-h-[60vh] overflow-y-auto">
            {(media ?? []).map((m: any) => (
              <button key={m.id} onClick={() => { onPick(m.public_url); setOpen(false); }}
                className="aspect-square rounded-lg overflow-hidden bg-white/5 hover:ring-2 hover:ring-primary transition-all">
                {m.mime_type?.startsWith("image/") ? <img src={m.public_url} alt={m.file_name} className="w-full h-full object-cover" /> : null}
              </button>
            ))}
          </div>
        </Modal>
      )}
    </>
  );
}

/* ---------------- Shared UI ---------------- */
function Modal({ children, title, onClose }: { children: React.ReactNode; title: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="glow-card w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10"><X className="h-4 w-4" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
function Row({ children }: { children: React.ReactNode }) { return <div className="grid sm:grid-cols-2 gap-3">{children}</div>; }
function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">{label}</span>
      {children}
    </label>
  );
}
function Input({ value, onChange, type = "text", placeholder }: { value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return <input type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)}
    className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-primary" />;
}
function Textarea({ value, onChange, rows = 3 }: { value: string; onChange: (v: string) => void; rows?: number }) {
  return <textarea rows={rows} value={value} onChange={(e) => onChange(e.target.value)}
    className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-primary resize-none" />;
}
function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-primary">
      {options.map((o) => <option key={o} value={o} className="bg-background">{o}</option>)}
    </select>
  );
}
