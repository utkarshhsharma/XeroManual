import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import toast from "react-hot-toast";
import { Phone, Mail, Calendar, ArrowRight, Loader2 } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { useSiteSettings } from "@/lib/site-data";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Book a Demo — XeroManual" },
      { name: "description", content: "Talk to XeroManual about your AI automation project. Book a free strategy call or send us a message." },
      { property: "og:title", content: "Contact XeroManual" },
      { property: "og:description", content: "Get in touch or book a free demo." },
    ],
  }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(2, "Name is required").max(100),
  email: z.string().trim().email("Valid email required").max(255),
  phone: z.string().trim().max(30).optional(),
  query_type: z.string().max(50).optional(),
  message: z.string().trim().min(5, "Message is required").max(1500),
});

const queryTypes = ["General Inquiry", "AI Receptionist", "WhatsApp Bot", "Custom AI Employee", "Pricing", "Other"];

function Contact() {
  const { data: settings } = useSiteSettings();
  const [form, setForm] = useState({ name: "", email: "", phone: "", query_type: "General Inquiry", message: "" });
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Invalid form");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("leads").insert(parsed.data);
    setSubmitting(false);
    if (error) {
      toast.error("Something went wrong. Please try again.");
      return;
    }
    toast.success("Message received! We'll get back to you shortly.");
    setForm({ name: "", email: "", phone: "", query_type: "General Inquiry", message: "" });
  }

  return (
    <SiteLayout>
      <section className="pt-20 pb-12">
        <div className="container-app text-center">
          <p className="text-sm font-semibold text-primary-glow mb-3">Get in Touch</p>
          <h1 className="text-4xl md:text-6xl font-bold text-gradient max-w-3xl mx-auto">Let's build something automatic</h1>
          <p className="mt-5 max-w-2xl mx-auto text-muted-foreground">
            Send us a message or book a call — usually get back within a few hours.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="container-app grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3 glow-card p-8">
            <h2 className="text-2xl font-bold mb-6">Send a message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Your Name" required>
                  <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="input-field" placeholder="Jane Doe" required />
                </Field>
                <Field label="Email" required>
                  <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="input-field" placeholder="you@company.com" required />
                </Field>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Phone">
                  <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="input-field" placeholder="+91 12345 67890" />
                </Field>
                <Field label="Query Type">
                  <select value={form.query_type} onChange={(e) => setForm({ ...form, query_type: e.target.value })}
                    className="input-field">
                    {queryTypes.map((t) => <option key={t} value={t} className="bg-background">{t}</option>)}
                  </select>
                </Field>
              </div>
              <Field label="Message" required>
                <textarea rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="input-field resize-none" placeholder="Tell us about what you'd like to automate..." required />
              </Field>
              <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-60">
                {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending...</> : <>Send Message <ArrowRight className="h-4 w-4" /></>}
              </button>
              <style>{`
                .input-field {
                  width: 100%; padding: 0.75rem 1rem; border-radius: 0.75rem;
                  background: oklch(1 0 0 / 0.05); border: 1px solid oklch(1 0 0 / 0.1);
                  color: oklch(0.97 0.01 280); font-size: 0.925rem;
                  transition: border-color 0.2s;
                }
                .input-field:focus { outline: none; border-color: oklch(0.68 0.24 300); }
                .input-field::placeholder { color: oklch(0.6 0.03 280); }
              `}</style>
            </form>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="glow-card p-8">
              <h3 className="text-lg font-bold mb-4">Instant Scheduling</h3>
              <p className="text-sm text-muted-foreground mb-5">Skip the back-and-forth. Pick a slot that works for you.</p>
              <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary w-full text-sm">
                <Calendar className="h-4 w-4" /> Book a Free Demo
              </a>
            </div>
            <div className="glow-card p-8 space-y-4">
              <ContactRow icon={<Phone className="h-4 w-4" />} label="Call us" value={settings?.phone ?? ""} href={`tel:${settings?.phone}`} />
              <ContactRow icon={<Mail className="h-4 w-4" />} label="Email" value={settings?.email ?? ""} href={`mailto:${settings?.email}`} />
              <div className="pt-3 border-t border-white/5">
                <p className="text-xs text-muted-foreground">Business hours</p>
                <p className="text-sm">Mon – Sat · 10am – 8pm IST</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
        {label}{required && <span className="text-primary-glow"> *</span>}
      </span>
      {children}
    </label>
  );
}

function ContactRow({ icon, label, value, href }: { icon: React.ReactNode; label: string; value: string; href: string }) {
  return (
    <a href={href} className="flex items-center gap-3 group">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 border border-white/10 group-hover:bg-brand-gradient transition-all">
        {icon}
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium group-hover:text-primary-glow transition-colors">{value}</p>
      </div>
    </a>
  );
}
