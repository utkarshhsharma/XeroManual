import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Target, Rocket, Users } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { useHomepageContent, useSiteSettings } from "@/lib/site-data";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About XeroManual — Our Story & Mission" },
      { name: "description", content: "XeroManual is a solo-founded AI automation studio helping ambitious businesses ship AI employees fast." },
      { property: "og:title", content: "About XeroManual" },
      { property: "og:description", content: "Our story and mission." },
    ],
  }),
  component: About,
});

function About() {
  const { data: hp } = useHomepageContent();
  const { data: settings } = useSiteSettings();

  return (
    <SiteLayout>
      <section className="pt-20 pb-12">
        <div className="container-app text-center">
          <p className="text-sm font-semibold text-primary-glow mb-3">About Us</p>
          <h1 className="text-4xl md:text-6xl font-bold text-gradient max-w-3xl mx-auto">A tiny studio with an outsized ambition</h1>
        </div>
      </section>

      <section className="pb-16">
        <div className="container-app max-w-3xl">
          <div className="glow-card p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-4">Our story</h2>
            <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{hp?.about_text}</p>
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="container-app max-w-3xl">
          <div className="glow-card p-8 md:p-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-gradient shadow-soft">
                <Target className="h-5 w-5 text-white" />
              </div>
              <h2 className="text-2xl font-bold">Our mission</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">{hp?.about_mission}</p>
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="container-app grid md:grid-cols-3 gap-6">
          <Feature icon={<Rocket className="h-5 w-5 text-white" />} title="Fast delivery" desc="Most builds live in under 14 days, not months." />
          <Feature icon={<Users className="h-5 w-5 text-white" />} title="Founder-led" desc="You work directly with the person building your automation." />
          <Feature icon={<Target className="h-5 w-5 text-white" />} title="Outcome-focused" desc="We measure success by hours saved and revenue unlocked." />
        </div>
      </section>

      <section className="pb-24">
        <div className="container-app text-center">
          <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary">
            Book a Free Demo <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </section>
    </SiteLayout>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="glow-card p-7">
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-gradient shadow-soft mb-4">{icon}</div>
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}
