import { Calendar } from "lucide-react";
import { useSiteSettings } from "@/lib/site-data";

export function FloatingCTA() {
  const { data: s } = useSiteSettings();
  if (!s?.meeting_link) return null;
  return (
    <a
      href={s.meeting_link}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-30 flex items-center gap-2 rounded-full bg-brand-gradient px-5 py-3 text-sm font-semibold text-white shadow-glow hover:scale-105 transition-transform"
      aria-label="Book a demo"
    >
      <Calendar className="h-4 w-4" />
      <span className="hidden sm:inline">Book a Free Demo</span>
    </a>
  );
}
