import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Sparkles } from "lucide-react";
import { useSiteSettings } from "@/lib/site-data";

const nav = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/packages", label: "Packages" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Navbar() {
  const { data: settings } = useSiteSettings();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full">
      <div className="glass border-b border-white/5">
        <div className="container-app flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            {settings?.logo_url ? (
              <img src={settings.logo_url} alt={settings.brand_name} className="h-8 w-auto" />
            ) : (
              <>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-gradient shadow-glow">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <span className="font-display text-lg font-bold tracking-tight">
                  {settings?.brand_name ?? "XeroManual"}
                </span>
              </>
            )}
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-full hover:bg-white/5"
                activeProps={{ className: "px-4 py-2 text-sm font-medium text-foreground rounded-full bg-white/5" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <a href={settings?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="btn-primary text-sm">
              Book a Demo
            </a>
          </div>

          <button
            onClick={() => setOpen((v) => !v)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5"
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <div className="md:hidden border-t border-white/5 px-6 py-4 space-y-1">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="block px-4 py-2 rounded-lg text-sm hover:bg-white/5"
              >
                {n.label}
              </Link>
            ))}
            <a
              href={settings?.meeting_link ?? "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary w-full mt-2 text-sm"
            >
              Book a Demo
            </a>
          </div>
        )}
      </div>
    </header>
  );
}
