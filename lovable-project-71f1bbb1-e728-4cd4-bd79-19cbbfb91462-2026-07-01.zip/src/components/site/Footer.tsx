import { Link } from "@tanstack/react-router";
import { Mail, Phone, Calendar, Sparkles } from "lucide-react";
import { useSiteSettings } from "@/lib/site-data";

export function Footer() {
  const { data: s } = useSiteSettings();
  return (
    <footer className="border-t border-white/5 mt-24">
      <div className="container-app py-16 grid md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-gradient shadow-glow">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="font-display text-lg font-bold">{s?.brand_name ?? "XeroManual"}</span>
          </div>
          <p className="mt-4 max-w-md text-sm text-muted-foreground leading-relaxed">
            AI automation, custom-built for ambitious founders. We ship AI employees that quietly run your business — while you sleep.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Navigate</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/services" className="hover:text-foreground">Services</Link></li>
            <li><Link to="/packages" className="hover:text-foreground">Packages</Link></li>
            <li><Link to="/about" className="hover:text-foreground">About</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Get in Touch</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Phone className="h-4 w-4" /><a href={`tel:${s?.phone ?? ""}`} className="hover:text-foreground">{s?.phone}</a></li>
            <li className="flex items-center gap-2"><Mail className="h-4 w-4" /><a href={`mailto:${s?.email ?? ""}`} className="hover:text-foreground">{s?.email}</a></li>
            <li className="flex items-center gap-2"><Calendar className="h-4 w-4" /><a href={s?.meeting_link ?? "#"} target="_blank" rel="noopener noreferrer" className="hover:text-foreground">Book a Demo</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5">
        <div className="container-app py-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} {s?.brand_name ?? "XeroManual"}. All rights reserved.</p>
          <p>Built for founders who move fast.</p>
        </div>
      </div>
    </footer>
  );
}
