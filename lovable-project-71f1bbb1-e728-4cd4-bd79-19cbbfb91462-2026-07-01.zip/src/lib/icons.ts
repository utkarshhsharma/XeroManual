import {
  Phone, CalendarCheck, Database, MessageCircle, Workflow, BrainCircuit,
  Sparkles, Bot, Zap, Users, Mail, LineChart, Rocket, Shield, type LucideIcon,
} from "lucide-react";

const map: Record<string, LucideIcon> = {
  Phone, CalendarCheck, Database, MessageCircle, Workflow, BrainCircuit,
  Sparkles, Bot, Zap, Users, Mail, LineChart, Rocket, Shield,
};

export function getIcon(name: string | null | undefined): LucideIcon {
  if (!name) return Sparkles;
  return map[name] ?? Sparkles;
}

export const iconNames = Object.keys(map);
