import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface SiteSettings {
  id: number;
  brand_name: string;
  logo_url: string | null;
  phone: string;
  email: string;
  meeting_link: string;
  starting_price_inr: number;
}

export interface Service {
  id: string;
  name: string;
  slug: string;
  short_description: string;
  long_description: string;
  features: string[];
  use_cases: string[];
  icon: string;
  image_url: string | null;
  sort_order: number;
  visible: boolean;
}

export interface Package {
  id: string;
  name: string;
  description: string;
  badge: string | null;
  short_code: string | null;
  features: string[];
  price_inr: number;
  featured: boolean;
  visible: boolean;
  sort_order: number;
}

export interface HomepageContent {
  id: number;
  hero_headline: string;
  hero_subheadline: string;
  hero_eyebrow: string;
  why_choose_us: { title: string; desc: string }[];
  testimonials: { quote: string; author: string; role: string }[];
  about_text: string;
  about_mission: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  query_type: string | null;
  message: string;
  status: string;
  created_at: string;
}

export function useSiteSettings() {
  return useQuery({
    queryKey: ["site_settings"],
    queryFn: async (): Promise<SiteSettings> => {
      const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).single();
      if (error) throw error;
      return data as SiteSettings;
    },
    staleTime: 60_000,
  });
}

export function useServices(includeHidden = false) {
  return useQuery({
    queryKey: ["services", includeHidden],
    queryFn: async (): Promise<Service[]> => {
      let q = supabase.from("services").select("*").order("sort_order");
      if (!includeHidden) q = q.eq("visible", true);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as Service[];
    },
  });
}

export function usePackages(includeHidden = false) {
  return useQuery({
    queryKey: ["packages", includeHidden],
    queryFn: async (): Promise<Package[]> => {
      let q = supabase.from("packages").select("*").order("sort_order");
      if (!includeHidden) q = q.eq("visible", true);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as Package[];
    },
  });
}

export function useHomepageContent() {
  return useQuery({
    queryKey: ["homepage_content"],
    queryFn: async (): Promise<HomepageContent> => {
      const { data, error } = await supabase.from("homepage_content").select("*").eq("id", 1).single();
      if (error) throw error;
      return data as unknown as HomepageContent;
    },
  });
}
