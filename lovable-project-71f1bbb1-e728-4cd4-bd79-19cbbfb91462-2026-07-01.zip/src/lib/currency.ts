// Simple INR-based currency conversion with IP geolocation.
// Rates are approximate; base stored price is always INR.

export interface CurrencyInfo {
  code: string;
  symbol: string;
  ratePerInr: number; // multiply INR by this to get local
  locale: string;
}

export const CURRENCIES: Record<string, CurrencyInfo> = {
  INR: { code: "INR", symbol: "₹", ratePerInr: 1, locale: "en-IN" },
  USD: { code: "USD", symbol: "$", ratePerInr: 0.012, locale: "en-US" },
  EUR: { code: "EUR", symbol: "€", ratePerInr: 0.011, locale: "en-DE" },
  GBP: { code: "GBP", symbol: "£", ratePerInr: 0.0094, locale: "en-GB" },
  AED: { code: "AED", symbol: "AED ", ratePerInr: 0.044, locale: "en-AE" },
  SGD: { code: "SGD", symbol: "S$", ratePerInr: 0.016, locale: "en-SG" },
  AUD: { code: "AUD", symbol: "A$", ratePerInr: 0.018, locale: "en-AU" },
  CAD: { code: "CAD", symbol: "C$", ratePerInr: 0.017, locale: "en-CA" },
  JPY: { code: "JPY", symbol: "¥", ratePerInr: 1.8, locale: "ja-JP" },
};

const countryToCurrency: Record<string, string> = {
  IN: "INR", US: "USD", GB: "GBP", DE: "EUR", FR: "EUR", ES: "EUR", IT: "EUR",
  NL: "EUR", IE: "EUR", AE: "AED", SG: "SGD", AU: "AUD", CA: "CAD", JP: "JPY",
};

export function formatPrice(inr: number, currency: CurrencyInfo): string {
  const converted = inr * currency.ratePerInr;
  const rounded = currency.code === "JPY" || currency.code === "INR"
    ? Math.round(converted)
    : Math.round(converted * 100) / 100;
  const formatted = new Intl.NumberFormat(currency.locale, {
    minimumFractionDigits: currency.code === "JPY" || currency.code === "INR" ? 0 : 2,
    maximumFractionDigits: currency.code === "JPY" || currency.code === "INR" ? 0 : 2,
  }).format(rounded);
  return `${currency.symbol}${formatted}`;
}

export async function detectCurrency(): Promise<string> {
  const cached = typeof window !== "undefined" ? localStorage.getItem("xm_currency") : null;
  if (cached && CURRENCIES[cached]) return cached;
  try {
    const res = await fetch("https://ipapi.co/json/", { signal: AbortSignal.timeout(3500) });
    if (!res.ok) throw new Error("geo failed");
    const data = await res.json();
    const code = countryToCurrency[data.country_code as string] ?? "INR";
    return code;
  } catch {
    return "INR";
  }
}
